const express = require('express');
const cors = require('cors');
const connection = require('./db_config')

const app = express();
app.use(express.json());
app.use(cors());



app.post('/cadastrarCliente', (req, res) => {
    const {email, nome, senha, cidade, filtros} = req.body;
    
    if(!email || !nome || !senha || !cidade || !filtros){
        return res.status(400).send({message: 'Todos campos são obrigatórios!'});
    }

connection.query(
    'INSERT INTO clientes (email_cliente, nome_cliente, senha_cliente, cidade, filtro_cliente) VALUES (?, ?, ?, ?, ?)', 
    [email, nome, senha, cidade, filtros],
    (err, result) => {
        if (err) {
            console.error('Erro ao cadastrar novo perfil no DB', err);
            return res.status(500).send({ message: 'Erro no servidor ao cadastrar' });
        }
        res.status(201).send({ message: 'Usuário cadastrado com sucesso!' });
    }
);
});
//////

app.post('/cadastrarEstabele', (req, res) => {
    const {nome, email, senha, cidade, descricao, filtros} = req.body;
    
    if(!nome || !email || !senha || !cidade || !descricao || !filtros){
        return res.status(400).send({message: 'Todos campos são obrigatórios!'});
    }

connection.query(
    'INSERT INTO estabelecimentos (nome_estabelecimento, email_estabelecimento, senha_estabelecimento, cidade_estabelecimento, descricao, filtros_estabelecimento) VALUES (?, ?, ?, ?, ?, ?)', 
    [nome, email, senha, cidade, descricao, filtros],
    (err, result) => {
        if (err) {
            console.error('Erro ao cadastrar novo estabelecimanto no DB', err);
            return res.status(500).send({ message: 'Erro no servidor ao cadastrar' });
        }
        res.status(201).send({ message: 'Estabelecimento cadastrado com sucesso!' });
    }
);
});

//////
app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    // Primeiro, tenta como cliente
    const clienteQuery = 'SELECT * FROM clientes WHERE email_cliente = ? AND senha_cliente = ?';
    connection.query(clienteQuery, [email, senha], (err, clienteResults) => {
        if (err) {
            console.error("Erro ao buscar cliente no banco:", err);
            return res.status(500).json({ success: false, message: 'Erro no servidor' });
        }

        if (clienteResults.length > 0) {
            return res.json({ success: true, tipo: 'cliente', message: 'Login como cliente bem sucedido' });
        }

        // Senão, tenta como estabelecimento
        const estabeleQuery = 'SELECT * FROM estabelecimentos WHERE email_estabelecimento = ? AND senha_estabelecimento = ?';
        connection.query(estabeleQuery, [email, senha], (err, estabeleResults) => {
            if (err) {
                console.error("Erro ao buscar estabelecimento no banco:", err);
                return res.status(500).json({ success: false, message: 'Erro no servidor' });
            }

            if (estabeleResults.length > 0) {
                return res.json({ success: true, tipo: 'estabelecimento', message: 'Login como estabelecimento bem sucedido' });
            }

            // Se não encontrou em nenhum dos dois:
            res.json({ success: false, message: 'Email ou senha incorretos' });
        });
    });
});



app.get('/pesquisarEstabelecimentos', (req, res) => {
    const termo = req.query.q;

    if (!termo) {
        return res.status(400).json({ message: 'Termo de busca não fornecido.' });
    }

    const query = `
        SELECT * FROM estabelecimentos 
        WHERE nome_estabelecimento LIKE ?
    `;

    const likeTerm = `%${termo}%`;

    connection.query(query, [likeTerm], (err, results) => {
        if (err) {
            console.error("Erro na pesquisa:", err);
            return res.status(500).json({ message: 'Erro ao realizar a pesquisa.' });
        }

        res.json(results);
    });
});

app.post('/cadastrarProduto', (req, res) => {
    const { nome, descricao, contem_gluten, contem_lactose, id_estabelecimento } = req.body;

    if (!nome || !descricao || typeof contem_gluten === 'undefined' || typeof contem_lactose === 'undefined' || !id_estabelecimento) {
        return res.status(400).send({ message: 'Todos os campos são obrigatórios!' });
    }

    const query = `
        INSERT INTO produtos (nome_produto, descricao_produto, contem_gluten, contem_lactose, id_estabelecimento)
        VALUES (?, ?, ?, ?, ?)
    `;

    connection.query(
        query, [nome, descricao, contem_gluten, contem_lactose, id_estabelecimento], (err, result) => {
            if (err) {
                console.error('Erro ao cadastrar produto:', err);
                return res.status(500).send({ message: 'Erro ao cadastrar o produto.' });
            }
            res.status(201).send({ message: 'Produto cadastrado com sucesso!' });
        }
    );
});

app.put('/editarCliente/:id', (req, res) => {
    const query = 'UPDATE clientes SET email_cliente = ?, nome_cliente = ?, senha_cliente = ?, cidade_cliente ?, filtros_cliente = ? WHERE id_cliente = ?'
    const {id} = req.params
    const {email, nome, senha, cidade, filtros} = req.body;

    if (!email || !nome || !senha || !cidade || !filtros) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios!' });
    }
    if (senha.length < 8) {
        return res.status(400).send("A senha precisa ter no mínimo 8 caracteres.");
    }
    if (senha.length > 15) {
        return res.status(401).send("A senha não pode ter mais que 15 caracteres.");
    }

    connection.query(query, [nome, email, senha, cidade, filtros, id], (err) => {
        if(err){
            return res.status(500).json({success: false, message: 'Erro ao editar usuário.'})
        }
       res.json({success: true, message: 'Usuário editado com sucesso'})
    })

})



app.put('/editarEstabele/:id', (req, res) => {
    const query = 'UPDATE estabalecimentos SET email_estabelecimento = ?, nome_estabelecimento = ?, senha_estabelecimento = ?, cidade_estabelecimento ?, filtros_estabelecimento = ? WHERE id_estabelecimento = ?'
    const {id} = req.params
    const {email, nome, senha, cidade, filtros} = req.body;

    if (!email || !nome || !senha || !cidade || !filtros) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios!' });
    }
    if (senha.length < 8) {
        return res.status(400).send("A senha precisa ter no mínimo 8 caracteres.");
    }
    if (senha.length > 15) {
        return res.status(401).send("A senha não pode ter mais que 15 caracteres.");
    }

    connection.query(query, [nome, email, senha, cidade, filtros, id], (err) => {
        if(err){
            return res.status(500).json({success: false, message: 'Erro ao editar usuário.'})
        }
       res.json({success: true, message: 'Usuário editado com sucesso'})
    })

})



app.put('/editarProduto/:id', (req, res) => {
    const query = 'UPDATE produtos SET nome_produto = ?, descricao_produto = ?, contem_gluten = ?, contem_lactose = ?, id_estabelecimento = ? WHERE id_produto = ?';
    const {id} = req.params
    const {nome, descricao, contem_gluten, contem_lactose, id_estabelecimento} = req.body;

    if (!nome || !senha || !cidade || !filtros) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios!' });
    }
    if (senha.length < 8) {
        return res.status(400).send("A senha precisa ter no mínimo 8 caracteres.");
    }
    if (senha.length > 15) {
        return res.status(401).send("A senha não pode ter mais que 15 caracteres.");
    }

    connection.query(query, [nome, descricao, contem_gluten, contem_lactose, id_estabelecimento, id], (err) => {
        if(err){
            return res.status(500).json({success: false, message: 'Erro ao editar usuário.'})
        }
       res.json({success: true, message: 'Usuário editado com sucesso'})
    })

})

app.delete('/deleteCliente/:email', (req, res) => {
    const {email} = req.params
    const query = 'DELETE FROM clientes WHERE email_cliente = ? AND senha_cliente = ?'
    connection.query(query, [email], (err) => {
        if(err){
            return res.status(500).json({success: false, message: 'Erro ao deletar usuário.'})
        }
        res.json({success: true, message: 'Usuário deletado com sucesso!'})
    })
})


app.delete('/deleteEstabelecimento/:email', (req, res) => {
    const {email} = req.params
    const query = 'DELETE FROM estabelecimentos WHERE email_estabelecimento = ? AND senha_estabelecimento = ?'
    connection.query(query, [email], (err) => {
        if(err){
            return res.status(500).json({success: false, message: 'Erro ao deletar usuário.'})
        }
        res.json({success: true, message: 'Usuário deletado com sucesso!'})
    })
})

app.delete('/deleteItem/:id', (req, res) => {
    const {id} = req.params
    const query = 'DELETE FROM Items WHERE id_item = ?'
    connection.query(query, [id], (err) => {
        if(err){
            return res.status(500).json({success: false, message: 'Erro ao deletar usuário.'})
        }
        res.json({success: true, message: 'Usuário deletado com sucesso!'})
    })
})


app.listen(3001, () => console.log(`Servidor rodando na porta 3001`))